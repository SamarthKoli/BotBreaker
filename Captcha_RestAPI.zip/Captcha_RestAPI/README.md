# DJango-REST-API-Experiments

This repository is a collection of projects and experiments created while learning Django REST Framework. It serves as a playground for testing out various concepts, building APIs, and understanding the RESTful services with Django.